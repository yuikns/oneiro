<?php get_header(); ?>
			<!--导航栏-->
            <div id="navbar">
            	<div id="nav-auto" class="primary">
				<?php wp_nav_menu( array('menu' => 'Header Menu','menu_id'=>'nav','container'=>'ul' )); ?> <!-- editable within the Wordpress backend -->
				</div>
                <div id="search">
                <?php get_search_form(); ?> 
                </div>
            </div>
			<!--导航栏结束-->
<article>
	<div id="article">
            <div class="xcontainer">
         
  			<div class="layout">
            
            
	<div id="content">
    <div class="content-header"></div>

		
			<h2>什么是404？</h2>
			
            
             <div class="post-meta-single"></div><!--.postMeta-->
            
            

			<div class="post-content">
<p>HTTP 404 错误意味着链接指向的网页不存在，即原始网页的URL失效，这种情况经常会发生，很难避免，比如说：网页URL生成规则改变、网页文件更名或移动位置、导入链接拼写错误等，导致原来的URL地址无法访问；当Web 服务器接到类似请求时，会返回一个404 状态码，告诉浏览器要请求的资源并不存在。</p>

<p>404 的含义：第一个 4 表示客户端出错，也就是服务器对你说：嘿，天堂有路你不走，404 无门你偏要闯进来；第二个 0 表示你把网址打错了；最后表示这个错误代码在 4 开头的错误代码中排行老四。</p>
<p style="text-align: center;"><img src="<?php bloginfo('template_url');?>/images/404.jpg" alt="404"  /></p>
			</div>
            
            
        

             
          

			
			
		
        
        <div class="clear"></div>
	</div><!--#content-->
<?php get_sidebar(); ?>
<div class="clear"></div>
</div><!--#layout-->

<?php get_footer(); ?>