<div  id="comments1"> 

<script language="javascript">
//<![CDATA[
function to_reply(commentID,author) {
var nNd='<a href=\'#comment-'+commentID+'\'>@'+author+' </a>';
var myField;
if (document.getElementById('comment') && document.getElementById('comment').type == 'textarea') {
myField = document.getElementById('comment');
document.getElementById('comment_parent').value = commentID;

} else {
return false;
}
if (document.selection) {
myField.focus();
sel = document.selection.createRange();
sel.text = nNd;
myField.focus();
}
else if (myField.selectionStart || myField.selectionStart == '0') {
var startPos = myField.selectionStart;
var endPos = myField.selectionEnd;
var cursorPos = endPos;
myField.value = myField.value.substring(0, startPos)
+ nNd
+ myField.value.substring(endPos, myField.value.length);
cursorPos += nNd.length;
myField.focus();
myField.selectionStart = cursorPos;
myField.selectionEnd = cursorPos;
}
else {
myField.value += nNd;
myField.focus();
}
}
//]]>
</script>
 
<style>
li {list-style-type:none;}
</style>

<div class="comments_warp">
<?php // 不能删除，这个是判断加密什么的……
if (isset($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
	die ('Please do not load this page directly. Thanks!');
if (post_password_required()) { ?>
	<h3 id="respond"><?php _e('This post is password protected. Enter the password to view comments.'); ?></h3>
<?php return; } ?>
<!-- 开始了 -->
<?php if (have_comments()): ?>

		<h3 id="comments"><?php comments_number('No Responses', 'One Response', '% Responses' );?> to &#8220;	<?php the_title(); ?>&#8221;</h3>


        <!--评论样式，具体的写到functions里了-->
        <?php if ( ! empty($comments_by_type['comment']) ) : ?>
      <ul class="commentlist">
            <?php wp_list_comments(array ('type' => 'comment','callback' => 'custom_comments')); ?>
      </ul>
        <?php endif; ?>
        
        
     <!--评论翻页--> 
      <div class="navigation">
            
         <?php paginate_comments_links(); ?>
      </div>
      
  
   <!--Pingbacklist去掉了--> 
   
   
    
<?php else : // this is displayed if there are no comments so far ?>

<?php endif; ?>


<!--输入框--> 
<?php if ('open' == $post->comment_status) : ?>
<div id="respond">
<h3 id="respondh3"><?php comment_form_title( __('Write a Comment') ); ?></h3>

<div class="cancel-reply"><?php cancel_comment_reply_link() ?></div>


    <!--判读有没有设置用户必须注册并登录才可以发表评论 --> 
    <?php if ( get_option('comment_registration') && !$user_ID ) : ?>
    <p><?php printf(__('You must be <a href="%s">logged in</a> to post a comment.'), get_option('siteurl') . '/wp-login.php?redirect_to=' . urlencode(get_permalink())); ?></p>
    <?php else : ?>
    <form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform" class="reply">
    	<?php if ( $user_ID ) : ?>
   			 <p><?php printf(__('Logged in as <a href="%1$s">%2$s</a>.'), get_option('siteurl') . '/wp-admin/profile.php', $user_identity); ?> <a href="<?php echo wp_logout_url(get_permalink()); ?>" title="<?php _e('Log out of this account'); ?>"><?php _e('Log out &raquo;'); ?></a></p>
   	 	<?php else : ?>
        
        
        
	<!--引用用代码开始-->
<!-- 有资料的访客 -->
<?php if ( $comment_author != "" ) : ?>
	<!--
		转换显示状态用的 JavaScript
		Q1: 为什么这段代码放在这里呢?
		A1: 因为只有当访客有资料时, 它才被用上, 这样可以减少无资料访客下载页面时的开销.
		Q2: 为什么不用外部文件将 JavaScript 放起来? 也许那样维护起来更方便.
		A2: 因为它只在这个地方用到了. 而且加载文件的数量也会影响页面下载速度, 为了这么点字节的代码, 不值得新开一个文件.
	-->
	<script type="text/javascript">function setStyleDisplay(id, status){document.getElementById(id).style.display = status;}</script>
	<div class="form_row small">
		<!-- 访客昵称 (随便欢迎一下) -->
		<span style="color:#999"><?php printf(__('哟，<strong>%s</strong>，欢迎回来！'), $comment_author) ?></span>
 
		<!-- 更改按钮 (点击后: 隐藏更改按钮, 显示取消按钮, 显示资料输入框) -->
		<span id="show_author_info"><a href="javascript:setStyleDisplay('author_info','');setStyleDisplay('show_author_info','none');setStyleDisplay('hide_author_info','');"><?php _e(' （换个马甲 &raquo;）'); ?></a></span>
 
		<!-- 取消按钮 (点击后: 显示更改按钮, 隐藏取消按钮, 隐藏资料输入框) -->
		<span id="hide_author_info"><a href="javascript:setStyleDisplay('author_info','none');setStyleDisplay('show_author_info','');setStyleDisplay('hide_author_info','none');"><?php _e('Close &raquo;'); ?></a></span>
	</div>
<?php endif; ?>
 
<!-- 资料输入框 -->
<div id="author_info">

		<label for="author" ><span class="authoricon"><?php _e('昵称'); ?> <?php if ($req) _e('(必填)'); ?></span></label>
	<div class="form_row">
		<input type="text" class="border"  name="author" id="author" value="<?php echo $comment_author; ?>" tabindex="1" />
	</div>
    
    	<label for="email" ><span class="emailicon"><?php _e('邮箱');?> <?php if ($req) _e('(必填)'); ?></span></label>
	<div class="form_row">
		<input type="text" class="border" name="email" id="email" value="<?php echo $comment_author_email; ?>" tabindex="2" />
		
	</div>
    
    
    	<label for="url" ><span class="urlicon"><?php _e('Website'); ?></span></label>
	<div class="form_row">
		<input type="text"  class="border" name="url" id="url" value="<?php echo $comment_author_url; ?>" tabindex="3" />
		
	</div>
 
</div>
 
<!-- 有资料的访客 -->
<?php if ( $comment_author != "" ) : ?>
	<!-- 隐藏取消按钮, 隐藏资料输入框 -->
	<script type="text/javascript">setStyleDisplay('hide_author_info','none');setStyleDisplay('author_info','none');</script>
<?php endif; ?>

<!--引用用代码结束--->
          

		<?php endif; ?>
        
<div class="input">
<p><textarea name="comment" id="comment" cols="100%" rows="10" tabindex="4" onkeydown="if(event.ctrlKey&&event.keyCode==13){document.getElementById('submit').click();return false};"></textarea></p>

</div>

<div class="clear"></div>

<!--smilies-->       

<div style=" margin-left:10px;"><?php wp_smilies();?></div>
<!--smilies-->

<input name="submit" type="submit" id="submit" tabindex="5" value="发表评论 (Ctrl+Enter)" class="comm_submit" /><?php comment_id_fields(); ?></p>
<?php do_action('comment_form', $post->ID); ?>

</form>
	<?php endif; // If registration required and not logged in ?>
</div>
<?php endif; // if you delete this the sky will fall on your head ?>
</div>

</div>
