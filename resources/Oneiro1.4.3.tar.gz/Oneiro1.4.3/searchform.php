<div id="search-bg"><span id="navulbghack"> </span>
<form method="get" id="searchform" class="search" action="<?php bloginfo('home');?>/">
	<div><input name="s" type="text" id="s" onblur="if(this.value =='')this.value='Search...';this.className='search_text';" onfocus="this.value='';this.className='search_textfocus';" onclick="if(this.value=='Search...')this.value=''" value="Search..." class="search_text" />
  <input type="submit" name="button" id="button" value="" class="search_submit" onmousemove="this.className='search_submithover'" onmousedown="this.className='search_submitactive'" onmouseout="this.className='search_submit'" /></div>
</form>

</div>